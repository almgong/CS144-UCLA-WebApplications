drop table if exists Bids;
drop table if exists Bidder;
drop table if exists ItemCategory;
drop table if exists Item;
drop table if exists Seller;